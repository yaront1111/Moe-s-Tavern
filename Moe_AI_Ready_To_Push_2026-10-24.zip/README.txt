Moe AI code quality: prepared changes

STATUS: Prepared and committed locally. NOT pushed to GitHub; no PR created.
The GitHub connector rejected blob creation with 403 (Resource not accessible
by integration), and native Git has no publishing credential. No branch
protection, review requirement, or authentication control was bypassed.

Repository: https://github.com/yaront1111/Moe-s-Tavern
Prepared branch: improve/ai-code-quality-context-20261024
Integration base: 9a9e1b9282662feeba16cd547251c08e06a93576
Fix commit: df9bc2e96766ba63a5ebdb3045a40377c2f8e605
Plan commit: dd46772ce0193b9e0766f585d8f5a0b73d70359f

Contents
- 2026-10-24-ai-code-quality-and-context.md: complete requested implementation plan.
- moe-ai-context-and-plan.patch: two git-format-patch commits, code fix first,
  Markdown plan second. The patch reproduces the prepared HEAD tree exactly.
- VALIDATION.json: validation, artifact hashes, and publication status.

Apply from a clean checkout with the intended latest main fetched:

  git fetch origin
  git switch -c improve/ai-code-quality-context-20261024 origin/main
  git am --3way /absolute/path/moe-ai-context-and-plan.patch

If main has changed overlapping code, review any conflicts and retest before
publishing. Do not overwrite unrelated work or force-update main.

Focused verification (Node 24):

  node --test --test-isolation=none --test-reporter=tap scripts/tests/prompt-cache-launcher.test.mjs
  bash -n scripts/moe-agent.sh
  bash scripts/tests/parity-check.sh

The existing CI additionally exercises Windows PowerShell 5.1, PowerShell 7,
and Git Bash. Windows runtime behavior has not been verified in this workspace.
The inspected base's prior green CI is not evidence for the prepared commits.

With authorized repository write credentials:

  git push -u origin HEAD

Open a PR from this branch to main. GitHub's Main ruleset requires one
approving review; preserve its normal review and CI gates.

Implementation scope
- Fix both launchers so they preserve the daemon-scoped task context.
- Add worker, QA, and sparse-context regressions against actual launcher blocks.
- Add the roadmap for approved-plan reuse, deterministic recipes, source-aware
  context caching, exact-candidate verification, and measured code quality.

Later roadmap tasks are proposals, not implemented runtime features.
Restored context may initially be larger. No token-savings or AI-code-quality
benchmark has been claimed.
